#ifndef LEX_H
#define LEX_h

#include "jeton.h"

//Fonction qui transforme une chaine de caractere en tableau de jeton
void detection_fonction(typejeton jeton[]);

#endif // LEX_H
