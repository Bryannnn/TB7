#include "graph.h"
#include "Evaluateur.h"

#define eaigu 130 //symbole pour � � et � (peut �tre une erreur)
#define egrave 138
#define aacent 133
#define ECHAP 27
#define longueur 100000
#define zoom 1.5

float bi, bs, pas, prec, bsb, bib, zerox, zeroy;
Arbre A;


//int basculea=0;

float maxi(float a, float b)
{
    if (a>b)
    {

        return a;

    }
    else
    {

        return b;
    }
}

float mini(float a, float b)
{
    if (a<b)
    {

        return a;

    }
    else
    {

        return b;
    }
}

void ouvreMenu()
{
    system("cls");
    printf("=============================! Bienvenue dans CALCULATOR 2000 !=============================\n\n \tQue voulez vous faire ? (appuez sur la lettre correspondante)\n\n \ta. Fonction\n\th. Help\n\n");


    switch(getch())
    {
    case 97: //Lance la fonction pour commencer
        system("cls");
        break;

    case 104:  //affiche l'aide
        system("cls");
        printf("=============================! Bienvenue dans CALCULATOR 2000 !=============================\n");
        printf("\n\tLa valeur 'precision' corrsepond au nombre de points dans l'intervalle\n");
        printf("\n\tAppuyez sur Z pour Zoomer");
        printf("\n\tAppuyez sur D pour Dezoomzer");
        printf("\n\tAppuyez sur S pour decaler a droite");
        printf("\n\tAppuyez sur Q pour decaler a gauche");
        printf("\n\tAppuyez sur R pour reset");
        printf("\n\t");
        printf("\n\t\t<Cliquez pour continuer>");
        getch();
        system("cls");
        ouvreMenu();
        break;

    case ECHAP:  //quitte le jeu
        system("cls");
        printf("=============================! Bienvenue dans GRAPHEUR !=============================\n\n \tAu revoir et %c bientot :)\n\n\n\n", aacent);
        exit(0);
        break;

    default:
        system("cls");
        ouvreMenu();
    }

}

/*float Evaluateur(float i)
{
    float r = sin(i);
    return r;
}*/

float valMax(Arbre A){

    float p = 0;
    float maximum = Evaluateur(A, bi);

    for(p=0; p<=prec; p++)
    {

        if (Evaluateur(A, bi+p*pas)>=maximum)
        {

            maximum = Evaluateur(A, bi+p*pas);
        }
    }
    return maximum;
}

float valMin(Arbre A){

    float p = 0;
    float minimum = Evaluateur(A, bi);

    for(p = 0; p<=prec; p++)
    {

        if (Evaluateur(A, bi+p*pas)<=minimum)
        {

            minimum = Evaluateur(A, bi+p*pas);
        }
    }
    return minimum;
}

void appuiD(){
    float coef;
    float mid = (bs+bi)/2;
    bi = mid - ((mid-bi)*zoom);
    bs = mid - ((mid-bs)*zoom);
    zerox = ((2*bi)/(bs-bi)) - 1;
    coef = bs-bi;
    pas = coef/prec;
}

void appuiQ(){
    bi = bi - (0.1*(bsb-bib));
    bs = bs - (0.1*(bsb-bib));
    zerox = ((2*bi)/(bs-bi)) - 1;
    pas = (bs-bi)/prec;
}

void appuiR(){
    bi = bib;
    bs = bsb;
    zerox = ((2*bi)/(bs-bi)) - 1;
    pas = (bs-bi)/prec;
}

void appuiS(){
    float coef;
    bi = bi + (0.1*(bsb-bib));
    bs = bs + (0.1*(bsb-bib));
    zerox = ((2*bi)/(bs-bi)) - 1;
    coef = bs-bi;
    pas = (coef)/prec;
}

void appuiZ(){
        float mid = (bs+bi)/2;
        float coef;
        bi = mid - ((mid-bi)/zoom);
        bs = mid - ((mid-bs)/zoom);
        zerox = ((2*bi)/(bs-bi)) - 1;
        coef = bs-bi;
        pas = (coef)/prec;
}

/**
* myKey
*
* Gestion des touches du clavier
*
* @parma c code ascci definissant une touche du clavier
*
*/
void myKey(int c)
{
    switch(c)
    {
    case 's':
        appuiS();
        break;

    case 'q':
        appuiQ();
        break;

    case 'z':
        appuiZ();
        break;

    case 'd':
        appuiD();
        break;

    case 'r':
        appuiR();
        break;

    case ECHAP:
        exit(0);

    case 'a':
        scanf("%s");

    default :
        break;
    }
}


/**
* myDraw
*
* Proc�dure
*
*/

void myDraw()
{
    Arbre As = A;
    float tabx[longueur];
    float taby[longueur];
    int i;
    float coef, mini, maxi;
    char total[100];

    mini = valMin(As);
    maxi = valMax(As);

        for(i = 0; i<=prec; i++)
        {
            tabx[i] = ((2*(i*pas))/(bs-bi))-1;
            taby[i] = -0.9 + (1.8*(Evaluateur(As ,bi+i*pas)-mini)/(maxi-mini));
        }

        setcolor(1.0F, 1.0F, 1.0F);

        for(i=0; i<prec-1; i++)
        {
            line(tabx[i], taby[i], tabx[i+1], taby[i+1]);
        }

    zerox = ((2*-bi)/(bs-bi)) - 1;
    zeroy = ((1.8*-valMin(As))/(valMax(As)-valMin(As))) - 0.9 ;


    if (zerox >= -1 && zerox <= 1 )
    {
        line(zerox, -0.9, zerox, 0.9);
    }

    if (valMin(As) <= 0 && valMax(As) >= 0)
    {
        line(-1, zeroy, 1, zeroy);
    }

    outtextxy(-1, 0.91, "Z : Zoom     D : Dezoom     Q : Deplacer a gauche       S : Deplacer a droite      R : Reset");
    sprintf(total, "En x : de %.2f a %.2f. En y : de %.2f a %.2f", bi, bs, valMin(As), valMax(As));
    outtextxy(-1, -0.98, total);
}

int main(int ac, char *av[])
{
    system("title Calculator 2000");

    ouvreMenu();

    float b1 = 0, b2 = 0;

    printf("=============================! Bienvenue dans CALCULATOR 2000 !=============================\n\n\t");

    //Partie analyse lexicale
    typejeton tab[100];
    detection_fonction(tab);
    printf("\n\t");

    //Partie analalyse syntaxique
    //typejeton tab_test[100];
    int i = 0;
    int* p = &i;
	A = AS(tab, p);
	afficher(A);

	system("cls");

    printf("=============================! Bienvenue dans CALCULATOR 2000 !=============================\n\n\ta) Appel avec Pas\n\n\tb) Appel avec Precision");

    switch(getch())
    {
    case 'a':
        system("cls");
        printf("=============================! Bienvenue dans CALCULATOR 2000 !=============================\n\n\tPremiere borne ");
        scanf("%f", &b1);

        printf("\n\tDeuxieme borne ");
        scanf("%f", &b2);

        printf("\n\tPas ");
        scanf("%f", &pas);

        if (b1 == b2 || pas == 0)
        {
            printf("Erreur");
            exit(0);
        }

        bib = mini(b1, b2);
        bsb = maxi(b1, b2);

        prec = (bsb-bib)/pas;

        break;

    case 'b':
        system("cls");
        printf("=============================! Bienvenue dans GRAPHEUR !=============================\n\n\tPremiere borne ");
        scanf("%f", &b1);

        printf("\n\t Deuxieme borne ");
        scanf("%f", &b2);

        printf("\n\tPrecision ");
        scanf("%f", &prec);

        if (b1 == b2 || prec == 0)
        {
            printf("Erreur");
            exit(0);
        }

        bib = mini(b1, b2);
        bsb = maxi(b1, b2);
        pas = (bsb-bib)/prec;

        break;

    default:

        break;
    }

    bs = bsb;
    bi = bib;

    InitGraph(ac,av,"Calculator 2000",1400,700,myDraw,myKey);

    return 0;
}


